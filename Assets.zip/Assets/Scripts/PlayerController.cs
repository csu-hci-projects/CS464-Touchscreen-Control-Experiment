using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;
using UnityEngine.SceneManagement;


public class PlayerController : MonoBehaviour
{
    public float speed;
    private Rigidbody2D rb2d;
    private int count;
    public Text countText;
    public Text winText;
    protected Joystick joystick;    
    void Start()
    {   
        joystick = FindObjectOfType<Joystick>();
        rb2d = GetComponent<Rigidbody2D> ();
        count = 0;
        winText.text = "";
        SetCountText();   
    }
    void FixedUpdate(){
    float moveHorizontal = joystick.Horizontal * speed + Input.GetAxis("Horizontal") * speed;
    float moveVertical = joystick.Vertical * speed + Input.GetAxis("Vertical") * speed;
    Vector2 movement = new Vector2 (moveHorizontal, moveVertical);
    rb2d.AddForce(movement * 2f);
    
    }
    
    void OnTriggerEnter2D(Collider2D other){
        if(other.gameObject.CompareTag("PickUp"))
        {
            other.gameObject.SetActive(false);
            count = count + 1;
            SetCountText();
        }
    }
    void SetCountText(){
        countText.text = "Count: " + count.ToString();
        if(count >= 15){
            winText.text = "You Win!!!";
            
           
        }
    }
}
