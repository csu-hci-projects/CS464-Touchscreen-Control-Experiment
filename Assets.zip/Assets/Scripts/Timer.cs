using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;
using System;
public class Timer : MonoBehaviour
{
    bool timerActive = true;
    float currentTime;
    public Text currentTimeText;
    public Text countText;
    void Start()
    {
        currentTime = 0;
    }
    void Update()
    {
        if(timerActive == true){
            currentTime = currentTime + Time.deltaTime;
         
        }
        TimeSpan time = TimeSpan.FromSeconds(currentTime);
        currentTimeText.text = time.ToString(@"mm\:ss\:f");
    }
    public void StartTimer(){
        timerActive = true;
    }
     public void StopTimer(){
        
        timerActive = false; 

    }
}