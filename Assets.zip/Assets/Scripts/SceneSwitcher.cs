using System.Collections;
using UnityEngine.SceneManagement;
using UnityEngine;

public class SceneSwitcher : MonoBehaviour
{
    public void showInstructions(){
         SceneManager.LoadScene("Instructions");
    }
    public void playTutorial() {
        
        SceneManager.LoadScene(SceneManager.GetActiveScene().buildIndex + 2);
    }
     public void playGame() {
        
        SceneManager.LoadScene(SceneManager.GetActiveScene().buildIndex + 4);
    
    }
    public void backToMain() {
        SceneManager.LoadScene(SceneManager.GetActiveScene().buildIndex - 1);
    }
    public void NextLevel()
    {
         SceneManager.LoadScene(SceneManager.GetActiveScene().buildIndex + 1);
    }
    public void BackToMain(){
         SceneManager.LoadScene(SceneManager.GetActiveScene().buildIndex - 3);
    }
    public void backToMainFromDpad() {
        SceneManager.LoadScene(SceneManager.GetActiveScene().buildIndex - 5);
    }
    public void quitButton(){
        Application.Quit();
    }
}


